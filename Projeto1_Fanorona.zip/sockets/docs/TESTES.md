# Registro de validação

Data: 06/09/2026. Ambiente: Windows, Eclipse Temurin JDK 21.0.12.1+1 portátil.

## Execução

Comando executado na raiz `sockets`:

```powershell
.\build.ps1 -JdkHome 'C:\Users\victo\Documents\GIT\.tools\jdk21\jdk-21.0.12.1+1'
```

Resultado: **40 verificações aprovadas**, compilação concluída e dois JARs gerados. A suíte também percorre até 300 passos em cada uma de 12 partidas com sementes fixas, verificando conservação de peças. As partidas geradas são verificações de invariantes, não prova exaustiva das regras.

O compilador precisou ser executado fora do sandbox do agente devido ao erro `Fatal Error: Cannot close compiler resources` no ambiente restrito. Fora dele, o mesmo script concluiu normalmente. Isso não exigiu alteração de permissões do repositório nem configuração global do Git.

## Verificações realizadas

- 22 peças por jogador, centro vazio e P1 iniciando.
- Linhas ortogonais, diagonais permitidas e limites de borda.
- Captura inicial obrigatória, turno correto e rejeição sem mutação.
- Aproximação, afastamento, múltiplas peças e parada em vazio ou aliado.
- Escolha exclusiva entre captura A e W.
- Continuação com a mesma peça, sem voltar à origem nem repetir direção.
- Encerramento opcional de sequência e proibição de passar turno.
- Movimento simples, vitória por eliminação e vitória por imobilização.
- Rejeição de modo inexistente, peça adversária e jogo encerrado.
- UTF-8, separadores em textos e limites de chat.
- Identificação e pareamento enquanto outro socket permanece sem HELLO.
- Snapshots idênticos recebidos pelos dois clientes após início e jogada.
- Rejeição de turno incorreto, número inválido e revisão antiga pela rede.
- Chat entre os clientes durante a partida e depois do resultado.
- Desistência, desconexão por EOF e empate por acordo.
- Isolamento de chat entre duas sessões e continuidade da segunda sessão.
- Encerramento do servidor e liberação do laço de accept.

## Revisão visual e empacotamento

A interface foi renderizada a partir do próprio Swing pelo utilitário `UiRender`, incluindo o tabuleiro inicial, o chat, os rótulos e os botões. O relatório foi renderizado e suas seis páginas foram inspecionadas para verificar legibilidade, tabelas, margens e paginação. Os manifestos dos JARs foram conferidos: apontam para FanoronaServer e FanoronaClient.

## Limites da validação

O teste TCP usa conexões reais em loopback. Não foi realizada uma partida manual completa nem um teste entre duas máquinas físicas. Não foram realizados ensaios de carga com 100 clientes, perdas de rede prolongadas, saturação de filas ou auditoria de segurança. O caminho Maven foi fornecido, mas a compilação validada foi pelo script PowerShell com JDK. Antes da apresentação, ensaie a interface e a conectividade na rede que será utilizada.
