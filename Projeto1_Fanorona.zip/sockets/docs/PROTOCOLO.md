# Protocolo TCP do Fanorona

Cada mensagem termina em LF; CR é ignorado. A codificação é UTF-8. Campos são separados por `|`; campos de texto são Base64 de UTF-8, sem quebras de linha. O servidor limita cada linha a 8192 caracteres. Índices do tabuleiro vão de 0 a 44, com `índice = linha * 9 + coluna`, ambos começando em zero.

## Cliente para servidor

| Mensagem | Significado |
|---|---|
| `HELLO|nome64` | Primeira mensagem, nome de 1 a 30 caracteres; timeout de 15 s |
| `MOVE|revisao|origem|destino|modo` | Movimento; modo `A` (aproximação), `W` (afastamento), `P` (simples) |
| `END_TURN|revisao` | Encerra uma sequência de capturas já iniciada |
| `CHAT|texto64` | Texto de 1 a 500 caracteres, sem controles |
| `FORFEIT` | Desistência, independentemente do turno |
| `DRAW` | Propõe empate ou aceita a oferta do outro jogador |

O ID do jogador é derivado da conexão; o cliente não pode escolher agir pelo adversário. `MOVE` e `END_TURN` exigem a revisão atual. Textos em branco ou com controles são rejeitados. Um comando inválido não altera o tabuleiro e recebe `ERROR`. Handshake inválido, mensagem acima do limite e falha de transporte fecham a conexão. Chat na espera recebe erro; está disponível durante e depois da partida.

## Servidor para cliente

| Mensagem | Campos |
|---|---|
| `INFO|texto64` | Espera, oferta de empate ou aviso |
| `WELCOME|id|nomeP1_64|nomeP2_64` | Identifica os participantes; P1 inicia |
| `STATE|revisao|turno|sequencia|matriz|jogadas` | Estado autoritativo completo |
| `CHAT|id|texto64` | Chat entregue a ambos os jogadores |
| `ERROR|texto64` | Rejeição entregue ao emissor |
| `OVER|vencedor|motivo64|m1|m2|c1|c2|i1|i2` | Vencedor 1/2 ou 0 empate; movimentos, capturas e comandos inválidos |

Na matriz, os 45 dígitos são `0` vazio, `1` branca e `2` preta, em ordem de linhas. `sequencia` é -1 fora de sequência ou o índice da peça que deve continuar. `jogadas` é uma lista separada por `;`, cada entrada `origem,destino,modo`; campo vazio significa ausência de movimentos. A revisão começa em zero e aumenta em cada movimento ou encerramento explícito de sequência. `OVER` é terminal para ações de jogo, mas não fecha o chat.

## Exemplo e fluxo

`HELLO|QW5h` identifica o nome Ana. Um cliente pode receber `WELCOME|1|QW5h|QnJ1bm8=` (Ana e Bruno). A jogada efetiva deve ser escolhida na lista do `STATE`; não se deve assumir que um exemplo fixo continua válido em qualquer posição.

Fluxo: conexão → HELLO → INFO de espera → WELCOME → STATE → MOVE/CHAT/END_TURN → STATE ou ERROR → OVER. A fila de escrita de cada cliente preserva a ordem de publicação da sessão. TCP não fornece recuperação de sessão após reconexão. A ausência de TLS e autenticação limita o uso a demonstrações em rede confiável.
