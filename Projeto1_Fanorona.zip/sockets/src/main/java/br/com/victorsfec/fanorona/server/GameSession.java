package br.com.victorsfec.fanorona.server;

import br.com.victorsfec.fanorona.game.Board;
import br.com.victorsfec.fanorona.shared.Protocol;
import java.util.stream.Collectors;

/** Autoridade da partida. O monitor serializa validação, alteração e publicação do estado. */
final class GameSession {
    private final ClientHandler[] players;
    private final Board board = new Board();
    private final int[] moves = new int[2], invalid = new int[2], captures = new int[2];
    private long revision;
    private boolean ended;
    private int drawOffer;
    GameSession(ClientHandler first, ClientHandler second) { players = new ClientHandler[]{first, second}; }
    synchronized void start() {
        for (int i = 0; i < 2; i++) {
            players[i].session = this;
            players[i].send("WELCOME|" + (i + 1) + "|" + Protocol.text(players[0].playerName) + "|" + Protocol.text(players[1].playerName));
        }
        publish();
    }
    synchronized void process(String line, ClientHandler sender) {
        int id = sender == players[0] ? 1 : 2;
        try {
            String[] p = Protocol.parts(line);
            if (p[0].equals("CHAT") && p.length == 2) {
                broadcast("CHAT|" + id + "|" + Protocol.text(Protocol.userText(p[1], 500))); return;
            }
            if (ended) throw new IllegalArgumentException("Partida encerrada.");
            switch (p[0]) {
                case "MOVE":
                    if (p.length != 5) throw new IllegalArgumentException("Formato MOVE inválido.");
                    checkRevision(p[1]);
                    captures[id - 1] += board.move(id, new Board.Move(Integer.parseInt(p[2]), Integer.parseInt(p[3]), p[4]));
                    moves[id - 1]++; changed(); break;
                case "END_TURN":
                    if (p.length != 2) throw new IllegalArgumentException("Formato END_TURN inválido.");
                    checkRevision(p[1]); board.endTurn(id); changed(); break;
                case "FORFEIT":
                    if (p.length != 1) throw new IllegalArgumentException("Formato inválido.");
                    finish(3 - id, "Desistência de P" + id); break;
                case "DRAW":
                    if (p.length != 1) throw new IllegalArgumentException("Formato inválido.");
                    if (drawOffer == 3 - id) finish(0, "Empate por acordo");
                    else { drawOffer = id; broadcast("INFO|" + Protocol.text("P" + id + " propôs empate. O adversário pode aceitar no botão Empate. Uma jogada cancela a oferta.")); }
                    break;
                default: throw new IllegalArgumentException("Comando desconhecido.");
            }
        } catch (IllegalArgumentException e) {
            invalid[id - 1]++; sender.send("ERROR|" + Protocol.text(e.getMessage()));
        }
    }
    private void checkRevision(String value) {
        if (Long.parseLong(value) != revision) throw new IllegalArgumentException("Estado desatualizado. Selecione a peça novamente.");
    }
    private void changed() {
        drawOffer = 0; revision++; publish();
        if (board.winner() != 0) finish(board.winner(), "Captura de todas as peças ou imobilização");
    }
    private void publish() {
        String legal = board.legalMoves().stream().map(Board.Move::wire).collect(Collectors.joining(";"));
        broadcast("STATE|" + revision + "|" + board.turn() + "|" + board.chain() + "|" + board.encode() + "|" + legal);
    }
    synchronized void disconnect(ClientHandler client) {
        if (!ended) finish(client == players[0] ? 2 : 1, "Desconexão do adversário");
    }
    private void finish(int winner, String reason) {
        if (ended) return;
        ended = true;
        broadcast("OVER|" + winner + "|" + Protocol.text(reason) + "|" + moves[0] + "|" + moves[1] + "|" + captures[0] + "|" + captures[1] + "|" + invalid[0] + "|" + invalid[1]);
    }
    private void broadcast(String message) { for (ClientHandler p : players) p.send(message); }
}
