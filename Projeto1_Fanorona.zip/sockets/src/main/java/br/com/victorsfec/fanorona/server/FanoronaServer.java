package br.com.victorsfec.fanorona.server;

import br.com.victorsfec.fanorona.shared.Protocol;
import java.io.IOException;
import java.net.*;
import java.util.*;

/** Aceita conexões sem aguardar o nome; um cliente lento não bloqueia o accept. */
public final class FanoronaServer implements AutoCloseable {
    private final ServerSocket listener;
    private final Set<ClientHandler> clients = new HashSet<>();
    private final Deque<ClientHandler> waiting = new ArrayDeque<>();
    private volatile boolean closed;
    public FanoronaServer(int port) throws IOException { listener = new ServerSocket(port); }
    public int port() { return listener.getLocalPort(); }
    public void run() throws IOException {
        while (!closed) {
            try {
                Socket socket = listener.accept();
                synchronized (this) {
                    if (closed || clients.size() >= 100) { socket.close(); continue; }
                    ClientHandler client = new ClientHandler(this, socket);
                    clients.add(client); client.start();
                }
            } catch (SocketException e) { if (!closed) throw e; }
        }
    }
    synchronized void ready(ClientHandler client) {
        if (closed || !clients.contains(client)) return;
        waiting.add(client);
        client.send("INFO|" + Protocol.text("Aguardando oponente. O primeiro conectado será P1 e iniciará."));
        if (waiting.size() >= 2) {
            ClientHandler first = waiting.remove(), second = waiting.remove();
            GameSession session = new GameSession(first, second);
            session.start();
        }
    }
    void remove(ClientHandler client) {
        synchronized (this) { clients.remove(client); waiting.remove(client); }
        // Não segurar o monitor do lobby ao adquirir o monitor da partida.
        GameSession session = client.session;
        if (session != null) session.disconnect(client);
    }
    @Override public void close() throws IOException {
        List<ClientHandler> copy;
        synchronized (this) { closed = true; copy = new ArrayList<>(clients); waiting.clear(); }
        listener.close();
        for (ClientHandler c : copy) c.shutdown();
    }
    public static void main(String[] args) throws Exception {
        int port = args.length == 0 ? Protocol.PORT : Integer.parseInt(args[0]);
        if (port < 1 || port > 65535) throw new IllegalArgumentException("Porta deve estar entre 1 e 65535");
        FanoronaServer server = new FanoronaServer(port);
        Runtime.getRuntime().addShutdownHook(new Thread(() -> { try { server.close(); } catch (IOException ignored) { } }));
        System.out.println("Fanorona TCP na porta " + server.port() + ". Ctrl+C para encerrar.");
        server.run();
    }
}
