# Projeto 1 — Fanorona com sockets TCP

Programação Paralela e Distribuída, IFCE, semestre 2026.2. Implementação em Java 21 e Swing, baseada na arquitetura do jogo Dara de `PPD_2026.1/sockets`.

## Início rápido

É necessário **JDK 21 ou superior** para compilar e **Java 21 ou superior** para executar os JARs. Java 8 não executa este projeto. Não há dependências externas de execução.

Na pasta `PPD_2026.2/sockets`, abra três terminais:

```powershell
# Terminal 1: servidor (porta padrão 12345)
java -jar target/sockets-1.0-server.jar

# Terminais 2 e 3: um cliente em cada terminal
java -jar target/sockets-1.0-client.jar
```

Nos clientes, informe nomes, `localhost` e porta `12345`. O primeiro jogador que concluir a identificação recebe P1 (brancas) e inicia; o segundo recebe P2 (pretas). Uma nova dupla forma uma sessão independente. O servidor funciona em terminal, inclusive sem ambiente gráfico; encerre-o com Ctrl+C. Para outra porta: `java -jar target/sockets-1.0-server.jar 15000`.

**Nesta máquina**, foi usado o JDK portátil em `C:\Users\victo\Documents\GIT\.tools\jdk21\jdk-21.0.12.1+1`. Caso `java` ainda aponte para Java 8, use o caminho completo:

```powershell
& 'C:\Users\victo\Documents\GIT\.tools\jdk21\jdk-21.0.12.1+1\bin\java.exe' -jar target/sockets-1.0-server.jar
& 'C:\Users\victo\Documents\GIT\.tools\jdk21\jdk-21.0.12.1+1\bin\java.exe' -jar target/sockets-1.0-client.jar
```

## Compilar e testar

Sem Maven e sem baixar dependências:

```powershell
.\build.ps1 -JdkHome 'C:\caminho\para\jdk-21'
```

O script compila fontes e testes, executa `AppTest` e só gera os JARs se os testes passarem. Pode-se configurar `JAVA_HOME` e executar apenas `.\build.ps1`. Os executáveis ficam em `target/sockets-1.0-server.jar` e `target/sockets-1.0-client.jar`.

Também é fornecido `pom.xml` para Maven 3.8+ com JDK 21:

```text
mvn clean package
```

O Maven usa `exec-maven-plugin` na fase `test` para executar a mesma suíte independente de JUnit. O primeiro uso exige acesso aos plugins Maven. O caminho de build validado nesta entrega é o script PowerShell; a configuração Maven é uma alternativa fornecida.

## Duas máquinas

1. Inicie o servidor em uma máquina da rede local.
2. Descubra o IPv4 dela com `ipconfig`.
3. Nos dois clientes, informe esse IPv4 e a porta do servidor. `localhost` só funciona para acessar a própria máquina.
4. Se necessário, permita a porta TCP escolhida no firewall da máquina servidora. Os clientes precisam alcançar o servidor, não um ao outro.

A verificação automatizada usa TCP real em loopback. A apresentação em máquinas distintas exige a verificação da rede e do firewall no local. Não há descoberta automática, TLS, autenticação ou reconexão com recuperação de partida.

## Como jogar

- O tabuleiro começa com 22 peças brancas e 22 pretas, em 45 interseções (5 linhas e 9 colunas); somente o centro está vazio.
- Clique numa peça sua. Os destinos permitidos pelo servidor aparecem em verde. Clique num deles para mover.
- A peça anda um ponto pelas linhas desenhadas; diagonais só existem nas interseções de paridade par.
- Se houver qualquer captura, a primeira jogada do turno deve capturar. Sem captura disponível, permite-se movimento simples (paika).
- **Aproximação (A):** captura a linha inimiga contígua além do destino, na direção do movimento.
- **Afastamento (W):** captura a linha inimiga contígua atrás da origem, no sentido oposto ao movimento.
- Quando ambos forem possíveis, uma janela pede a escolha. Nunca são aplicados os dois modos no mesmo passo.
- Depois de capturar, pode-se continuar com a mesma peça, sem revisitar ponto (incluindo a origem) nem repetir a direção imediatamente anterior. O botão **Encerrar sequência** permite parar; se não houver continuação, a vez muda automaticamente.
- Vence quem elimina todas as peças adversárias. Este projeto também considera derrota por imobilização. **Desistir** concede vitória ao adversário e pede confirmação.
- **Empate** propõe ou aceita empate por acordo. Uma jogada cancela a proposta pendente.
- O chat suporta acentos, `:` e `|`, até 500 caracteres por mensagem, e continua funcionando após o resultado. Para uma nova partida, feche os clientes e abra-os novamente.

### Decisões sobre regras

O PDF é a fonte dos requisitos. Ele diz que o jogador **pode continuar** capturando; por isso a continuação é opcional nesta implementação. Captura inicial obrigatória, escolha exclusiva entre A/W, paridade das diagonais e proibição de repetir direção consecutiva complementam os detalhes resumidos no enunciado. Imobilização e empate por acordo são convenções adicionais documentadas; não há empate automático por repetição ou por limite de jogadas. A variante de revanche Vela não é implementada.

Referência complementar consultada: [ICGA — Fanorona](https://icga.org/icga/games/Fanorona/). Algumas variantes exigem continuar capturando; essa exigência não foi adotada porque o PDF permite a escolha.

## Hierarquia preservada

```text
PPD_2026.2/
└── sockets/
    ├── pom.xml
    ├── build.ps1
    ├── README.md
    ├── src/
    │   ├── main/java/br/com/victorsfec/fanorona/
    │   │   ├── client/   FanoronaClient, GameFrame, ResultsDialog
    │   │   ├── server/   FanoronaServer, ClientHandler, GameSession
    │   │   ├── game/     Board, Piece
    │   │   └── shared/   Protocol
    │   └── test/java/br/com/victorsfec/fanorona/
    │       ├── AppTest.java
    │       └── client/UiRender.java
    ├── docs/
    │   ├── Relatorio_Projeto1.pdf
    │   ├── PROTOCOLO.md
    │   └── gerar_relatorio.py
    └── target/
        ├── sockets-1.0-server.jar
        └── sockets-1.0-client.jar
```

Mantiveram-se a raiz `sockets`, a disposição Maven e os quatro pacotes de responsabilidade do trabalho anterior. O nome do pacote `dara` passou a `fanorona`, e os pontos de entrada foram renomeados para o novo jogo. `Piece` documenta a identidade das peças; a matriz usa valores inteiros para facilitar snapshots compactos.

## Modificações em relação ao Dara

| Aspecto | Base 2026.1 | Projeto 2026.2 |
|---|---|---|
| Regras | Dara, 5 × 6, colocação e trincas | Fanorona, 5 × 9, posição inicial completa e captura em linhas |
| Organização | Maven, client/server/game/shared | Mesma hierarquia, pacote fanorona |
| Rede | Socket/ServerSocket e handler por cliente | Mesmo padrão, identificação no handler com timeout |
| Estado | Eventos de colocar/mover/remover | Snapshot completo e numerado após cada ação |
| Concorrência | Sessão com métodos synchronized | Monitor da sessão + fila de saída limitada por cliente |
| Validação | Algumas entradas convertidas diretamente | Formato, limites, identidade, turno, revisão e regra validados |
| Desconexão | Tratamento centrado em exceção de leitura | EOF e exceção passam pelo mesmo encerramento |
| Interface | Swing e resultados do Dara | Linhas do Fanorona, destinos válidos e escolha A/W |
| Demonstração | Comando de chat `/endgame` altera tabuleiro | Cenários exclusivamente nos testes; chat nunca altera regras |
| Build | Maven com shade e JUnit 4.11 | JAR sem dependências, Maven ou script JDK |

O reaproveitamento é arquitetural: separação de responsabilidades, modelo cliente-servidor, handlers, sincronização e atualização Swing pela EDT. O código foi reescrito/adaptado para as novas regras e para corrigir fragilidades identificadas na base. Não se trata de manter o motor do Dara sob outro nome. Os logs diários em arquivo e a tentativa de reconexão automática da base não foram transportados; o histórico do chat fica em memória na interface.

## Concorrência e comunicação para a apresentação

`FanoronaServer` aceita conexões e mantém o lobby. `ClientHandler` lê comandos de um jogador. Cada dupla recebe uma `GameSession`; seu método `process` é `synchronized`, portanto duas threads não alteram o mesmo tabuleiro ao mesmo tempo. Partidas diferentes possuem monitores independentes.

O socket TCP oferece fluxo ordenado de bytes, não mensagens. `Protocol.readLine` separa mensagens pelo fim de linha e limita cada quadro a 8192 caracteres. Textos são Base64 sobre UTF-8, o que preserva separadores dentro do nome/chat; Base64 não é criptografia. A versão `revision` evita aplicar cliques enviados a partir de um tabuleiro antigo.

O servidor publica `STATE` com matriz, turno, peça da sequência e movimentos legais. A interface envia intenções, mas não confirma movimentos por conta própria. Filas de saída limitadas impedem que uma escrita bloqueante segure o monitor da sessão. Ao saturar a fila, a conexão é fechada. O limite de clientes é 100; a identificação deve chegar em até 15 segundos.

No cliente, uma thread recebe dados e agenda atualizações com `SwingUtilities.invokeLater`; um executor serializa os envios. A EDT desenha e recebe cliques. As tarefas de rede não bloqueiam a interface. Encerrar a conexão encerra a participação; não há retomada automática.

## Testes e roteiro de demonstração

`AppTest` verifica disposição inicial, diagonais, turno, capturas A/W e exclusividade, obrigatoriedade, sequência, direção, visita, finalização, vitória e codificação. Também abre servidor em porta efêmera e clientes TCP para verificar pareamento, snapshots, comandos inválidos, revisão antiga, chat, desistência, desconexão e empate. `UiRender` permite renderizar o Swing para revisão visual; não substitui o ensaio interativo.

Para apresentar: (1) inicie servidor e dois clientes; (2) mostre P1 iniciando e tente clicar com P2; (3) mova para o centro e escolha A/W se solicitado; (4) mostre a captura refletida nas duas telas; (5) demonstre chat com acentos; (6) explique a sequência e o botão de encerramento; (7) desista e mostre o resultado; (8) abra nova dupla e feche um cliente para mostrar desconexão; (9) execute o build para demonstrar os testes de cenários difíceis. Para localizar regras, comece por `Board.legalMoves` e `Board.move`; para PPD, por `ClientHandler` e `GameSession.process`.

Fontes do trabalho: `Projeto 1.pdf` fornecido pelo professor e código local de `PPD_2026.1/sockets`. O PDF também contém orientações de entrega e apresentação; este projeto não envia emails nem publica o repositório automaticamente.
